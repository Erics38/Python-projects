const AWS = require('aws-sdk');

// Configure SES service
const ses = new AWS.SES({ region: 'us-east-1' });

exports.handler = async (event) => {
    console.log('Lambda was triggered!');
    console.log('Number of messages received:', event.Records.length);

    try {
        const firstMessage = event.Records[0];
        const guestbookData = JSON.parse(firstMessage.body);

        console.log('Sending email for:', guestbookData.name);

        // Create email parameters
        const emailParams = {
            Source: 'syvertsene37@gmail.com', 
            Destination: {
                ToAddresses: ['syvertsene37@gmail.com'] 
            },
            Message: {
                Subject: {
                    Data: 'New Guestbook Entry!'
                },
                Body: {
                    Text: {
                        Data: `Name: ${guestbookData.name}\nMessage: ${guestbookData.message}`
                    }
                }
            }
        };

        // Send the email
        const result = await ses.sendEmail(emailParams).promise();     
        console.log('Email sent! Message ID:', result.MessageId);      

        return {
            statusCode: 200,
            body: 'Email sent successfully!'
        };

    } catch (error) {
        console.error('Lambda failed:', error);
        throw error;
    }
};